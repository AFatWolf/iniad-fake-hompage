ace.define("ace/snippets/typescript",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="typescript"});                (function() {
                    ace.require(["ace/snippets/typescript"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            