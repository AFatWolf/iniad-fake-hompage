var mode = <div> 
    Typescript + <b> JSX </b> 
</div>;